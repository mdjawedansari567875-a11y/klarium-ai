# KLARIUM AI — Full App (Onboarding + Main App merged)

This is the complete, merged project: onboarding flow + the full main app
(Home chat, Leaderboard, Settings) all wired together in one working codebase.

## Flow
1. **Onboarding** (first launch only): Welcome splash → Class select (1–12) →
   NCERT/CBSE select → Name entry → drops straight into the main app.
2. **Main App** (bottom tabs):
   - **Home** — chat with the AI (text or photo), streak tracking runs quietly
     in the background, and a test popup appears automatically every 7 active days.
   - **Leaderboard** — ranked list of weekly test scores.
   - **Settings** — Gemini API key field + "GENERATE API KEY" button (opens
     Google AI Studio to create one), "Developer & Idea" credits, and
     "Contact Support" (opens email to amdjawed753@gmail.com).

Once onboarding is completed, the app remembers this (`AsyncStorage`) and
opens straight to Home on every future launch — the onboarding screens are
skipped.

## Firebase — now wired in (live)
The app is connected to your real Firebase project (`klarium-ai`):
- **Authentication (Anonymous)** — every device signs in silently in the
  background on app launch (`src/services/authService.js`). No login screen,
  no password — each install just gets a stable, unique ID.
- **Firestore** — the leaderboard (`src/services/progressService.js`) reads
  and writes to a `leaderboard` collection, one document per user, keyed by
  their anonymous Firebase uid. `LeaderboardScreen` subscribes to this
  collection live, so scores update in real time for every user, not just
  the device that took the test.

### Before the 30-day test mode expiry
Firestore's "test mode" (which you started in) allows open read/write for
30 days, then locks the database. Before that happens, replace it with the
rules in **`firestore.rules`** (already included in this project) — they:
- Let anyone read the leaderboard (needed to show everyone's scores)
- Only let a user write to their **own** score document (can't edit others')

To apply them: Firebase Console → Firestore Database → Rules tab → paste
the contents of `firestore.rules` → Publish.

## Required setup before the AI works
1. Get a **free Gemini API key**: open the app → Settings → tap
   "GENERATE API KEY" (or go to https://aistudio.google.com/app/apikey directly).
2. Paste it into the API key field in Settings and tap Save.
3. Now Home's chat + photo explanations will work.

## First-time tutorial
The very first time a user reaches Home, a step-by-step walkthrough appears
automatically, teaching them: open Settings → find the API Key section →
tap "GENERATE API KEY" → paste the key back → Save. It only shows once
(tracked via AsyncStorage `klarium_tutorial_seen`) and can be skipped.

## API key 24-hour expiry
Every time a key is saved in Settings, a 24-hour timer starts
(`klarium_api_key_saved_at` in AsyncStorage). Settings shows a live countdown
("Xh Ym remaining"). Once it hits zero, any chat/photo/quiz request is blocked
with a message asking the user to regenerate or re-save the key in Settings —
re-saving (even the same key) restarts the 24-hour window.

## How to run this on your phone
```bash
cd klarium-ai
npm install
npx expo start
```
Scan the QR code with the **Expo Go** app (Android or iOS) to preview live.

## What's NOT built yet
- Push notifications for streak reminders
- App icon / splash image assets (currently just solid premium dark background)
- Firestore security rules applied (see "Before the 30-day test mode expiry" above — do this within 30 days)
